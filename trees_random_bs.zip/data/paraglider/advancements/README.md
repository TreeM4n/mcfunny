# Advancements

Advancements are given by a trigger inside of Minecraft, or the `/advancement` command. The example in this tab uses the `minecraft:impossible` trigger, this is due to automatically triggering if a player doesn't already have it (see tick.mcfunction). There are many triggers available. As a result, I recommend, especially if you are new, using [misode.github.io](https://misode.github.io) for some amazing generators.
